/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 *
 * @author steinybear
 */
public class P4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        System.out.println(new File(".").getAbsolutePath());
        String ifnm = "auth.log.txt", ofnm = "invalidUsers.txt";
        switch (args.length) {
            case 0:
                break;
            case 2:
                ofnm = args[1]; // fall through
            case 1:
                ifnm = args[0];
                break;
            default:
                System.out.println
                ("Usage: At most two file names expected");
                System.exit(0);
        }
        processData(ifnm, ofnm);
    }
    
    public static void processData(String ifnm, String ofnm) throws IOException {
        //String ipPattern = "\\p{Digit}+\\.\\p{Digit}+\\.\\p{Digit}+\\.\\p{Digit}+'";
        Pattern ipPattern = Pattern.compile("\\d+\\.\\d+\\.\\d+\\.\\d+\\.");
        //Matcher matcher = ipPattern.matcher(ifnm);
        Stream<String> lines = Files.lines(Paths.get(ifnm));
        FileWriter outWriter = new FileWriter(ofnm);
        int index = 1;
        
        lines.filter(line -> line.contains("Invalid user") && line.contains("from"))
                .map(line -> line.split(" "))   // Get an array of strings by splitting on spaces on this tring
                .map(arr -> arr[arr.length -1]) // The ip is the last of these strings
                .forEach(ip -> writeToFile(outWriter, ip)); // Write each ip
        outWriter.close();
        lines.close();
    }
    
    private static int count = 1;
    private static void writeToFile(FileWriter fw, String packageName) {
        try {
            fw.write(String.format("%d %s\n", count++, packageName));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
