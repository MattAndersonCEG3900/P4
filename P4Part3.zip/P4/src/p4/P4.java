/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/**
 *
 * @author steinybear
 */
public class P4 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        System.out.println(new File(".").getAbsolutePath());
        String[] files = {"http://short-story.me/science-fiction-stories/1057-a-real-girl.html",
                          "http://short-story.me/science-fiction-stories/1054-timing-isnt-everything.html",
                          "http://short-story.me/science-fiction-stories/1051-huns-vs-nuns.html",
                          "http://short-story.me/science-fiction-stories/1047-waterhole.html",
                          "http://short-story.me/science-fiction-stories/1035-the-boy-made-of-circles.html",
                          "http://short-story.me/science-fiction-stories/1021-blue-moon-diner.html",
                          "http://short-story.me/science-fiction-stories/961-two-minutes.html",
                          "http://short-story.me/science-fiction-stories/944-why-does-bobby-fly.html",
                          "http://short-story.me/science-fiction-stories/934-the-ultimate-weapon.html",
                          "http://short-story.me/science-fiction-stories/899-ethical-dilemmas.html"};
        int n = 10;
        String ifnm;
        String ofnm = "invalidUsers.txt";
        switch (args.length) {
            case 0:
                break;
            case 2:
                ofnm = args[1]; // fall through
            case 1:
                ifnm = args[0];
            case 3:
                n = Integer.parseInt(args[2]);
            default:
                System.out.println
                ("Usage: At most two file names expected");
                System.exit(0);
        }
        processData(n, files, ofnm);
    }
    
    public static void processData(int n, String[] files, String ofnm) throws IOException {
        Stream<List<String>> allFiles;

        Comparator<String> byWord = (e1, e2) -> String.compareTo(e1.getKey(), e2.getKey());
        allFiles = Stream.of(Arrays.asList(files)); //reader.lines();
        allFiles.flatMap(str -> str.stream())
                .filter(line -> line.contains("<p>"))
                .map(line -> line.replace("<p>", ""))
                .map(line -> line.replace("</p>", ""))
                .map(line -> line.replace(".", ""))
                .map(line -> line.replace(",", ""))
                .map(line -> line.replace("!", ""))
                .map(line -> line.replace("?", ""))
                .map(line -> line.replace(":", ""))
                .map(line -> line.replace(";", ""))
                .map(line -> line.toLowerCase())
                .map(line -> line.split(" "))
                .map(line -> new SimpleEntry<>(line, 1))
                .sorted( (e1, e2) ->  e1.getKey().compareTo(e2.getKey()))
//                .reduce(new LinkedHashMap<>(), (acc, entry) -> {
//                    acc.put(entry.getKey(), acc.compute(entry.getKey(), (k, v) -> v == null ? 1 : v + 1));
//                    return acc;
//                    }, (m1, m2) -> m1);
//                   
                    //totalLines.
                    ;    
        
        FileWriter outWriter = new FileWriter(ofnm);
        
        outWriter.close();
        allFiles.close();
    }
    
    private static int count = 1;
    private static void writeToFile(FileWriter fw, String packageName) {
        try {
            fw.write(String.format("%d %s\n", count++, packageName));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
